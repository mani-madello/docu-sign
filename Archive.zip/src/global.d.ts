declare interface Window {
  pdfjsWorker: Worker;
}
