<script setup lang="ts">
import UploadContent from './components/UploadContent.vue';
</script>

<template>
  <div class="upload layout step">
    <upload-content />
  </div>
</template>
