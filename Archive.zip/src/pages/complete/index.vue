<script setup lang="ts">
import CompleteContent from './components/CompleteContent.vue';
</script>

<template>
  <div class="complete layout step">
    <complete-content />
  </div>
</template>
