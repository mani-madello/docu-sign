<template>
  <div class="w-full h-full flex items-center justify-center animate-pulse">
    <img
       src="@/assets/logo/logo_darkbg_horizontal.png"
      class="animate-bounce w-2/3 max-w-[400px]"
      alt="logo"
    />
  </div>
</template>
