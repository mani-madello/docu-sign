<script setup lang="ts">
import SignatureContent from './components/SignatureContent.vue';
</script>

<template>
  <div class="signature layout step">
    <signature-content />
  </div>
</template>
