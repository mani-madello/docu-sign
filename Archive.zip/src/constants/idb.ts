export const IDB_KEY = {
  CURRENT_PDF: 'pdf_signature_currentPDF',
  PDF_LIST: 'pdf_signature_PDF',
  ARCHIVE_LIST: 'pdf_signature_archive',
  TRASH_LIST: 'pdf_signature_trash',
};
