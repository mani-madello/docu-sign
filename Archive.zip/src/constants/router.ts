export const ROUTER_INJECT_KEY = Symbol('inject-router');
