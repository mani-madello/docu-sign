export interface Loading {
  isShow: boolean;
  title: string;
  content: string;
  isProcess: boolean;
  completeness: number;
}
