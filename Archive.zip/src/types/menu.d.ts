export type MenuTab = 'file' | 'archive' | 'trash';
export type FileShowStatus = 'list' | 'card';
export type SignatureTool = 'sign' | 'image' | 'literal' | 'page';
