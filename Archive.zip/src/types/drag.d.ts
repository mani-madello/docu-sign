export interface DragOffset {
  x: number;
  y: number;
  width: number;
  height: number;
}
