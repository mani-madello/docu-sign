export { default as Checkbox } from './src/index.vue';
