export { default as BatchOperation } from './src/index.vue';
