/** Default duration (ms) */
export const DURATION = 2000;
/** The interval between each prompt message (y) */
export const SPACE_Y = 8;
/** Default z-index (level greater than or equal to route animation) */
export const Z_INDEX = 50;
