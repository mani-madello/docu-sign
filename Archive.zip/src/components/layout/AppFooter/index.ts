export { default as AppFooter } from './src/index.vue';
